' Startet das Atomkraftwerk ohne sichtbares Fenster (wird von der Aufgabenplanung aufgerufen)
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
ordner = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = ordner
sh.Run """C:\Program Files\dotnet\dotnet.exe"" """ & ordner & "\Atomkraftwerk.dll""", 0, False
